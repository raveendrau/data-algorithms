Name: Xing Su
Date Started: 4/2/13
Date Completed:4/4/13
Estimated Hours: 15
Sources & Individuals Consulted: Yang Su & Kevin Gao for how to use the Debug mode properly


Notes:  
		None;