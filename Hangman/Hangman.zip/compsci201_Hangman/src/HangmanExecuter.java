/**
 * This class launches the Hangman game
 * and plays once.
 * 
 * Note to students: if you modify this file (you don't need to), add 
 * your name!
 * 
 * @author Michael Hewner
 * @author Mac Mason
 */
public class HangmanExecuter {

	public static void main(String[] args) {
		HangmanGame game = new HangmanGame();
		game.play();
	}
}
	
